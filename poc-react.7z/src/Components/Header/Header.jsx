import React, { Component } from "react";
import  "../Header/Header.css";
class Header extends Component {
    render() {
        return(
            <div>
               <p>header</p>
            </div>
        );
    }

}

export default Header;