import React, { Component } from "react";
import  "../Footer/Footer.css";
class Footer extends Component {
    render() {
        return(
            <div>
                <p>Footer</p>
            </div>
        );
    }

}

export default Footer;