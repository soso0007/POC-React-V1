import React from 'react'

const ProcessManagment=()=>{
    return(
        <div>
            <h1>Process Managment</h1>
            <div>User Name : <input type='text'/> </div>
            <div>password  : <input type='password'/></div>
        </div>
    )
}

export default ProcessManagment